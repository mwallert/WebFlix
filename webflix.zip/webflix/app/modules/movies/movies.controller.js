﻿
angular.module('webflixApp')
    .controller('MoviesController', MoviesController);

function MoviesController() {
    var vm = this;

    vm.test = 'Hello Everyone!';
}